// AI-generated: "WebSocket server on port 3001, syncs game via Redis pub/sub, handles client connections and messages."
const WebSocket = require('ws');
const Redis = require('ioredis');
const TicTacToe = require('./game');

const redis = new Redis(); // Default localhost:6379
const pub = new Redis();
const GAME_CHANNEL = 'tic-tac-toe-sync';

const wss = new WebSocket.Server({ port: 3001 });
let clients = [];
let game = new TicTacToe();

redis.subscribe(GAME_CHANNEL);

redis.on('message', (channel, message) => {
    if (channel === GAME_CHANNEL) {
        const msg = JSON.parse(message);
        if (msg.type === 'move') {
            if (game.makeMove(msg.row, msg.col, msg.player)) {
                broadcastUpdate();
            }
        }
    }
});

function broadcastUpdate() {
    const state = game.getState();
    clients.forEach(ws => {
        ws.send(JSON.stringify({ type: 'update', ...state }));
        if (state.winner) {
            ws.send(JSON.stringify({ type: state.winner === "draw" ? "draw" : "win", winner: state.winner }));
        }
    });
}

wss.on('connection', ws => {
    clients.push(ws);
    ws.send(JSON.stringify({ type: 'update', ...game.getState() }));

    ws.on('message', msg => {
        try {
            const data = JSON.parse(msg);
            if (data.type === 'move') {
                if (game.isValidMove(data.row, data.col, data.player)) {
                    game.makeMove(data.row, data.col, data.player);
                    broadcastUpdate();
                    // Sync move to other server
                    pub.publish(GAME_CHANNEL, JSON.stringify({ type: 'move', row: data.row, col: data.col, player: data.player }));
                } else {
                    ws.send(JSON.stringify({ type: 'error', message: 'Invalid move.' }));
                }
            }
        } catch (e) {
            ws.send(JSON.stringify({ type: 'error', message: 'Malformed message.' }));
        }
    });

    ws.on('close', () => {
        clients = clients.filter(c => c !== ws);
    });
});

console.log("Server A running on port 3001");