// AI-generated: "Implement core Tic-Tac-Toe game logic: board, move validation, win/draw detection."
class TicTacToe {
    constructor() {
        this.board = [
            ["", "", ""],
            ["", "", ""],
            ["", "", ""]
        ];
        this.nextTurn = "X";
        this.winner = null;
        this.moves = 0;
    }

    isValidMove(row, col, player) {
        if (this.winner) return false;
        if (player !== this.nextTurn) return false;
        if (row < 0 || row > 2 || col < 0 || col > 2) return false;
        if (this.board[row][col] !== "") return false;
        return true;
    }

    makeMove(row, col, player) {
        if (!this.isValidMove(row, col, player)) return false;
        this.board[row][col] = player;
        this.moves++;
        this.checkWinner(row, col, player);
        this.nextTurn = player === "X" ? "O" : "X";
        return true;
    }

    checkWinner(row, col, player) {
        // Check row, col, diagonals
        const b = this.board;
        if (
            b[row][0] === player && b[row][1] === player && b[row][2] === player ||
            b[0][col] === player && b[1][col] === player && b[2][col] === player ||
            b[0][0] === player && b[1][1] === player && b[2][2] === player ||
            b[0][2] === player && b[1][1] === player && b[2][0] === player
        ) {
            this.winner = player;
        } else if (this.moves === 9) {
            this.winner = "draw";
        }
    }

    getState() {
        return {
            board: this.board,
            nextTurn: this.nextTurn,
            winner: this.winner
        };
    }
}

module.exports = TicTacToe;