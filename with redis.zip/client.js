// AI-generated: "CLI WebSocket client for Tic-Tac-Toe game, connects to a server, displays board, allows moves, shows real-time updates."
const WebSocket = require('ws');
const readline = require('readline');

const SERVER_URL = process.argv[2] || 'ws://localhost:3001'; // Or ws://localhost:3002

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let player = null;
let nextTurn = null;
let board = null;

function printBoard(b) {
    console.clear();
    console.log('\n  0   1   2');
    b.forEach((row, i) => {
        console.log(i + ' ' + row.map(cell => cell || ' ').join(' | '));
        if (i < 2) console.log('  ---------');
    });
}

const ws = new WebSocket(SERVER_URL);

ws.on('open', () => {
    rl.question('Choose your player (X/O): ', answer => {
        player = answer.toUpperCase() === 'O' ? 'O' : 'X';
        ws.send(JSON.stringify({ type: 'join', playerId: player }));
        console.log(`You are "${player}". Waiting for game updates...`);
    });
});

ws.on('message', msg => {
    const data = JSON.parse(msg);
    if (data.type === 'update') {
        board = data.board;
        nextTurn = data.nextTurn;
        printBoard(board);
        if (nextTurn === player && !data.winner) {
            rl.question('Your move (row,col): ', input => {
                const [row, col] = input.split(',').map(Number);
                ws.send(JSON.stringify({ type: 'move', row, col, player }));
            });
        }
    } else if (data.type === 'win') {
        console.log(`Game over! Winner: ${data.winner}`);
        process.exit();
    } else if (data.type === 'draw') {
        console.log('Game over! Draw.');
        process.exit();
    } else if (data.type === 'error') {
        console.log('Error:', data.message);
    }
});