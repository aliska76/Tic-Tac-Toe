# Real-Time Tic-Tac-Toe Over Two Servers

## Architecture

- **Backend:** Two Node.js WebSocket servers (`serverA.js` on port 3001, `serverB.js` on port 3002)
    - Each server keeps its own client connections and game state.
    - Servers synchronize moves in real-time via Redis Pub/Sub.
    - Game logic is shared via `game.js`.

- **Client:** CLI-based Node.js script (`client.js`)
    - Connects to either backend server via WebSocket.
    - Displays board, accepts moves, shows real-time updates.

## Communication Protocols

- **Client ↔ Server:**
    - `join`, `move`, `update`, `win`, `draw`, `error` (see `client.js`)
- **Server ↔ Server:**
    - Redis Pub/Sub: On valid move, publish to `tic-tac-toe-sync` channel; both servers listen and update state.

## How to Run

1. **Install dependencies:**
    ```bash
    npm install ws ioredis readline
    ```

2. **Start Redis:**
    - Ensure Redis is running locally (`localhost:6379`). You can use Docker:  
      ```bash
      docker run --name redis -p 6379:6379 redis
      ```

3. **Run both servers in separate terminals:**
    ```bash
    node serverA.js
    node serverB.js
    ```

4. **Run two clients in separate terminals:**
    ```bash
    node client.js ws://localhost:3001
    node client.js ws://localhost:3002
    ```

## Play a Game

- Each client chooses a player ("X" or "O") when starting.
- Enter moves as `row,col` (e.g., `1,2`).
- Moves instantly reflect on both clients.
- Invalid moves are rejected.
- Game ends with win or draw notification.

## AI Tool Usage

- All core files were prompted and generated with Copilot (prompt examples in code comments).
- Prompts used:
    - "Implement core Tic-Tac-Toe game logic: board, move validation, win/draw detection."
    - "WebSocket server on port 3001, syncs game via Redis pub/sub, handles client connections and messages."
    - "CLI WebSocket client for Tic-Tac-Toe game, connects to a server, displays board, allows moves, shows real-time updates."
- Manual improvements: Added error handling, improved board display, clarified communication protocol.

## Notes

- You can run multiple games by restarting the servers.
- You may configure Redis in `.env` if needed.